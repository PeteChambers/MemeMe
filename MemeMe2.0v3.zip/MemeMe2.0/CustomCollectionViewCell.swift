//
//  CustomCollectionViewCell.swift
//  Experiment1
//
//  Created by Pete Chambers on 07/12/2017.
//  Copyright © 2017 Pete Chambers. All rights reserved.
//

import UIKit

class CustomCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var memeImageView: UIImageView!
    
    
    
    
    
    
    
    
}
