//
//  Meme Struct.swift
//  Experiment1
//
//  Created by Pete Chambers on 23/11/2017.
//  Copyright © 2017 Pete Chambers. All rights reserved.
//

import Foundation
import UIKit
// Meme Struct

struct Meme {
    let topText: String
    let bottomText: String
    let origionalImage: UIImage!
    var memedImage: UIImage!
    
}

